class SpellInfo {
	__Initialize() { ; Initialize instance variables *Important: will flag errors if omitted* TODO: perhaps these just need to be class variables
		MagicPage := ""
		YCoord := ""
		HotKeyName := ""
		SpellEffectImg := ""
		SpellEffectDuration := ""

		RequiredWandSlot := ""
	}

    __New(aSpellName, aMagicPage, aCoord, aHK, eImg := "", eDuration := "", requiredWandSlot := "") { ; Constructor
		this.SpellName := aSpellName
        this.MagicPage := aMagicPage
        this.YCoord := aCoord
		this.HotKeyName := aHK
		this.SpellEffectImg := eImg
		this.SpellEffectDuration := eDuration
		this.RequiredWandSlot := requiredWandSlot

		if (this.HotKeyName != "") {
			Hotkey(this.HotKeyName, this.CastSpell.Bind(this), "ON") ; Bind the hotkey so whenever it is struck it calls the CastSPell function
		}

		; Add to global tracking array
        global SpellInfoInstances
        SpellInfoInstances.Push(this)
    }

	Disable(*) {
		Hotkey(this.HotKeyName, DoNothing, "Off")
	}

	CastSpell(*) {
		Global CastingEffectSpell, LastCastspell

		if WinActive(WinTitle) ; This supposedly stops the hotkey from working outside of the HB client
		{
			BlockInput "MouseMove"
			MouseGetPos &begin_x, &begin_y ; Get the position of the mouse

			if (GetKeyState("LButton", "P")) ; if we are holding down m1, like when we are chasing someone, the cast should interrupt the run so the cast doesn't fail
			{
				Send("{LButton up}")
			}

			if (GetKeyState("RButton", "P")) ; if we are holding down m1, like when we are chasing someone, the cast should interrupt the run so the cast doesn't fail
			{
				Send("{RButton up}")
			}


			; Wand-required spells: equip ONLY when RequiredWandSlot is a positive integer (> 0).
			; Blank, missing, or 0 means: do NOT equip, just cast.
			wandSlot := 0
			wandSlotStr := Trim(this.RequiredWandSlot)
			if (wandSlotStr != "" && RegExMatch(wandSlotStr, "^\d+$"))
				wandSlot := Integer(wandSlotStr)
			if (wandSlot > 0) {
				EquipItem([wandSlot], true)
				Sleep 10
			}
			Send("^{" this.MagicPage "}") ; Open Magic menu tab ^{#}
			Sleep 10
			MouseClick("L", CtPixel(SpellHorizontalPos, "X"), CtPixel(this.YCoord, "Y"),, 0)
			Sleep 10
			MouseMove begin_x, begin_y, 0 ; Move mouse back to original position
			BlockInput "MouseMoveOff"

			LastCastspell := this.SpellName

			if (this.SpellEffectDuration != "")
			{	
				CastingEffectSpell := [] ; Must set the variable as an array to start.
				CastingEffectSpell.Push(this.SpellEffectImg)
				CastingEffectSpell.Push(this.SpellEffectDuration)
			}
		}
	}
}